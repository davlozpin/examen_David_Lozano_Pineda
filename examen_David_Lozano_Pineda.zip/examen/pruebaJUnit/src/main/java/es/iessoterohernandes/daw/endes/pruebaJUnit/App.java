package es.iessoterohernandes.daw.endes.pruebaJUnit;

public class App {
    
    public static void main(String[] args) {
    }
    
}
